<?php require_once "./header.php" ?>
<style>
    * {
        padding: 0;
        margin: 0;
        font-family: sans-serif;
        box-sizing: border-box;
    }
    .container {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 50px 8%;
    position: absolute;
    top: 5%;
    right: 10%;
    height: 100%;
  }
    

    .container img {
        height: auto;
        width: 420px;
    }
    .about-text{
        width: 550px;

    }
    .main{
        width: 1130px;
        max-width: 95%;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-around;
    }
    .about-text h1{
        color: white;
        font-size: 80px;
        text-transform: capitalize;
        margin-bottom: 20px;
    }
    .about-text h5{
        color: white;
        font-size: 60px;
        text-transform: capitalize;
       margin-bottom: 25px;
       letter-spacing: 2px;

    }
    span{
        color: #009688;
    }
    .about-text p{
        color: #fcfc;
        letter-spacing: 1px;
        line-height: 28px;
        font-size: 18px;
        margin-bottom: 45px;
    }
    .highlight {
    color: #009688; }
</style>
<div class="container">

    <div class="main">
        <img src="https://cdn.pixabay.com/photo/2021/07/28/12/56/specs-6500153_1280.jpg" alt="">
        <div class="about-text">
            <h1>About Us</h1>
            <h5><span class="highlight">Retailer</span> <span >& Seller</span></h5>
            <p>Lorem ipsum dolor sit amet Quibusdam quos dicta, beatae saepe doloribus
                inventore perferendis unde natus porro velit ducimus asperiores quas, dolor
                nam, eligendi laudantium odio aliquid fugit autem dolorum, cumque iusto debitis saepe!
                Officia, nesciunt pariatur. Itaque animi quae dolore in? Eius accusantium quam,
                fugiat natus cumque molestiae cum sequi iste ad error vitae amet quae, molestias
                dolorem dicta? Aperiam, ipsa dolore? Quae.
            </p>
        </div>
    </div>

</div>
<?php require_once "./footer.php" ?>